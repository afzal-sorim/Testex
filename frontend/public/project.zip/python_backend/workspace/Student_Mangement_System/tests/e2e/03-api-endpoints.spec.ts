import { test, expect } from '@playwright/test';

test.describe('API Endpoint Sanity Checks', () => {

  test('Endpoint GET /students responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /students/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students/{id}', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /students/new responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students/new', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint POST /students responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students', { method: 'POST' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /students/edit/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students/edit/{id}', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint POST /students/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students/{id}', { method: 'POST' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /students/delete/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/students/delete/{id}', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET / responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /error responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/error', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /h2-console responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/h2-console', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint POST /h2-console responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/h2-console', { method: 'POST' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /favicon.ico responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/favicon.ico', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });
});
