import { test, expect } from '@playwright/test';

test.describe('Business Flows', () => {

  test('Business Flow:  (0)', async ({ page, baseURL }) => {
    await page.goto(baseURL || '/');
    await page.waitForLoadState('networkidle');
    await expect(page.locator('body')).toBeVisible();
    await page.waitForTimeout(1000);
  });

  test('Business Flow:  (1)', async ({ page, baseURL }) => {
    await page.goto(baseURL || '/');
    await page.waitForLoadState('networkidle');
    await expect(page.locator('body')).toBeVisible();
    await page.waitForTimeout(1000);
  });

  test('Business Flow:  (2)', async ({ page, baseURL }) => {
    await page.goto(baseURL || '/');
    await page.waitForLoadState('networkidle');
    await expect(page.locator('body')).toBeVisible();
    await page.waitForTimeout(1000);
  });

  test('Business Flow:  (3)', async ({ page, baseURL }) => {
    await page.goto(baseURL || '/');
    await page.waitForLoadState('networkidle');
    await expect(page.locator('body')).toBeVisible();
    await page.waitForTimeout(1000);
  });
});
