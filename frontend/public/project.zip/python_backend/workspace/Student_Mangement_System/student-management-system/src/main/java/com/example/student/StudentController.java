package com.example.student;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private AppUserRepository appUserRepository;

    private boolean isAuthenticated(HttpSession session) {
        return session.getAttribute("user") != null;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/students";
    }

    @GetMapping("/login")
    public String loginPage(HttpSession session) {
        if (isAuthenticated(session)) {
            return "redirect:/students";
        }
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        var user = appUserRepository.findByUsername(username);
        
        if (user.isPresent() && user.get().getPassword().equals(password)) {
            session.setAttribute("user", username);
            return "redirect:/students";
        }
        
        if ("admin".equals(username) && "admin".equals(password)) {
            session.setAttribute("user", "admin");
            return "redirect:/students";
        }
        
        model.addAttribute("error", "Invalid username or password");
        return "login";
    }

    @GetMapping("/signup")
    public String signupPage(HttpSession session) {
        if (isAuthenticated(session)) {
            return "redirect:/students";
        }
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam String username, @RequestParam String password, @RequestParam String confirmPassword, Model model) {
        if (appUserRepository.findByUsername(username).isPresent()) {
            model.addAttribute("error", "Username already exists");
            return "signup";
        }
        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Passwords do not match");
            return "signup";
        }
        
        AppUser newUser = new AppUser(username, password);
        appUserRepository.save(newUser);
        
        model.addAttribute("success", "Account created successfully! You can now log in.");
        return "login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/students")
    public String listStudents(Model model, HttpSession session, @RequestParam(required = false) String keyword) {
        if (!isAuthenticated(session)) {
            return "redirect:/login";
        }
        
        if (keyword != null && !keyword.trim().isEmpty()) {
            model.addAttribute("students", studentRepository.findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(keyword, keyword));
            model.addAttribute("keyword", keyword);
        } else {
            model.addAttribute("students", studentRepository.findAll());
        }
        
        return "index";
    }

    @GetMapping("/students/add")
    public String showAddStudentForm(Model model, HttpSession session) {
        if (!isAuthenticated(session)) {
            return "redirect:/login";
        }
        model.addAttribute("student", new Student());
        return "add-student";
    }

    @PostMapping("/students/add")
    public String addStudent(@ModelAttribute("student") Student student, HttpSession session) {
        if (!isAuthenticated(session)) {
            return "redirect:/login";
        }
        studentRepository.save(student);
        return "redirect:/students";
    }

    @GetMapping("/students/edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model, HttpSession session) {
        if (!isAuthenticated(session)) {
            return "redirect:/login";
        }
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid student Id:" + id));
        model.addAttribute("student", student);
        return "update-student";
    }

    @PostMapping("/students/update/{id}")
    public String updateStudent(@PathVariable("id") long id, @ModelAttribute("student") Student student, HttpSession session) {
        if (!isAuthenticated(session)) {
            return "redirect:/login";
        }
        student.setId(id);
        studentRepository.save(student);
        return "redirect:/students";
    }

    @GetMapping("/students/delete/{id}")
    public String deleteStudent(@PathVariable("id") long id, HttpSession session) {
        if (!isAuthenticated(session)) {
            return "redirect:/login";
        }
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid student Id:" + id));
        studentRepository.delete(student);
        return "redirect:/students";
    }
}
