import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir: './tests/e2e',
  reporter: [['html'], ['json', { outputFile: 'playwright-report/test-results.json' }]],
  use: { 
    baseURL: process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:8081',
    video: 'on',
    trace: 'on',
    screenshot: 'on'
  },
});
