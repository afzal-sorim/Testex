import { test, expect } from '@playwright/test';

test.describe('Navigation & Core Routing', () => {
  test('Homepage loads successfully without errors', async ({ page, baseURL }) => {
    const response = await page.goto(baseURL || '/');
    await page.waitForLoadState('networkidle');
    expect(response?.status()).toBeLessThan(400);
    await expect(page.locator('body')).toBeVisible();
    
    // Explicitly fail if a generic Spring Boot/Jetty error page is returned
    const bodyText = await page.locator('body').innerText();
    expect(bodyText).not.toContain('Whitelabel Error');
    expect(bodyText).not.toContain('Error 404');
  });

  test('Page title is populated', async ({ page, baseURL }) => {
    await page.goto(baseURL || '/');
    await page.waitForLoadState('networkidle');
    const title = await page.title();
    expect(title.length).toBeGreaterThan(0);
    expect(title).not.toMatch(/404|Error/i);
  });
});
