import { test, expect } from '@playwright/test';

test.describe('API Endpoint Sanity Checks', () => {

  test('Endpoint GET /tasks responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/tasks', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint GET /tasks/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/tasks/{id}', { method: 'GET' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint POST /tasks responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/tasks', { method: 'POST' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint PUT /tasks/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/tasks/{id}', { method: 'PUT' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });

  test('Endpoint DELETE /tasks/{id} responds', async ({ request, baseURL }) => {
    const response = await request.fetch((baseURL || '') + '/tasks/{id}', { method: 'DELETE' });
    // Just verify it doesn't hard-crash (some may return 401/403/400 which is fine, 500 is bad)
    expect(response.status()).not.toBe(500);
  });
});
