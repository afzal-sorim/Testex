import React, { useState, useEffect } from 'react';
import { 
  FileText, Download, CheckCircle, FileCode, Server, Play, FolderArchive, ArrowDownToLine, RefreshCw
} from 'lucide-react';
import { motion } from 'framer-motion';
import { 
  getPlaywrightStatus, 
  getBrdDownloadUrl,
  getUiTestCasesDownloadUrl,
  getApiTestCasesDownloadUrl,
  getPlaywrightReportDownloadUrl,
  API_BASE_URL
} from '../api';

export default function Summary({ repoUrl, setActiveTab }) {
  const repoName = repoUrl ? repoUrl.split('/').pop().replace('.git', '') : '';
  const [loading, setLoading] = useState(false);
  const [playwrightResult, setPlaywrightResult] = useState(null);

  useEffect(() => {
    if (repoName) {
      const fetchStatus = async () => {
        try {
          const pwStatus = await getPlaywrightStatus(repoName);
          setPlaywrightResult(pwStatus);
        } catch (err) { console.error(err); }
      };
      fetchStatus();
      
      const intervalId = setInterval(fetchStatus, 3000);
      return () => clearInterval(intervalId);
    }
  }, [repoName]);

  const handleDownload = (type) => {
    if (!repoName) return;
    setLoading(true);
    let url = '';
    switch (type) {
      case 'brd':
        url = `${API_BASE_URL}/brd/download/${encodeURIComponent(repoName)}`;
        break;
      case 'report':
        url = `${API_BASE_URL}/migration/${repoName}/playwright/report/download`;
        break;
      case 'api-tests':
        url = `${API_BASE_URL}/reports/api-test-cases/download/${encodeURIComponent(repoName)}`;
        break;
      case 'ui-tests':
        url = `${API_BASE_URL}/reports/ui-functional-test/download/${encodeURIComponent(repoName)}`;
        break;
      default:
        break;
    }
    
    if (url) {
      window.open(url, '_blank');
    }
    setTimeout(() => setLoading(false), 1000);
  };

  const passedTests = playwrightResult?.passedTests || 0;
  const failedTests = playwrightResult?.failedTests || 0;
  const totalTests = playwrightResult?.totalTests || (passedTests + failedTests);
  const successRate = totalTests > 0 ? Math.round((passedTests / totalTests) * 100) : 0;

  return (
    <div className="flex flex-col gap-6 animate-fadeIn w-full pb-10">
      
      {/* Top Section: Metrics Overview */}
      <div className="mb-2">
        <p className="text-sm font-medium text-[#667085] mb-6">Overview of test execution metrics and central repository for all generated artifacts</p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-2xl p-6 border border-[#EAECF0] flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-[#5B5FF6]">
                <FolderArchive size={24} />
              </div>
              <div>
                <p className="text-xs font-bold text-[#667085] mb-1">Total Test Cases</p>
                <p className="text-2xl font-black text-[#101828]">{totalTests}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-6 border border-[#EAECF0] flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500">
                <CheckCircle size={24} />
              </div>
              <div>
                <p className="text-xs font-bold text-[#667085] mb-1">Passed</p>
                <p className="text-2xl font-black text-[#101828]">{passedTests}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-6 border border-[#EAECF0] flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
              </div>
              <div>
                <p className="text-xs font-bold text-[#667085] mb-1">Failed</p>
                <p className="text-2xl font-black text-[#101828]">{failedTests}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-2xl p-6 border border-[#EAECF0] flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-500">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
              </div>
              <div>
                <p className="text-xs font-bold text-[#667085] mb-1">Success Rate</p>
                <p className="text-2xl font-black text-[#101828]">{successRate}%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Report Downloads */}
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-[#EAECF0]">
        <h2 className="text-lg font-bold text-[#101828] mb-8 flex items-center gap-2">
          <Download size={20} className="text-[#5B5FF6]" /> Report Downloads
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* BRD Report */}
          <div className="border border-[#EAECF0] rounded-2xl p-6 bg-white hover:border-[#5B5FF6] hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-[#98A2B3]">
                  <FileText size={20} />
                </div>
                <button 
                  onClick={() => handleDownload('brd')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-[#5B5FF6] text-xs font-bold rounded-lg hover:bg-indigo-100 transition-colors"
                >
                  <Download size={14} /> Download
                </button>
              </div>
              <h3 className="text-sm font-bold text-[#101828] mb-2">BRD Report</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Business Requirements Document generated during the Discovery phase outlining project scope and specifications.
              </p>
            </div>
          </div>

          {/* UI Test Cases Summary */}
          <div className="border border-[#EAECF0] rounded-2xl p-6 bg-white hover:border-[#5B5FF6] hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-[#98A2B3]">
                  <FileText size={20} />
                </div>
                <button 
                  onClick={() => handleDownload('ui-tests')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-[#5B5FF6] text-xs font-bold rounded-lg hover:bg-indigo-100 transition-colors"
                >
                  <Download size={14} /> Download
                </button>
              </div>
              <h3 className="text-sm font-bold text-[#101828] mb-2">UI Test Cases Summary</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Comprehensive listing of all generated UI test cases in PDF or ZIP format.
              </p>
            </div>
          </div>

          {/* API Test Cases Summary */}
          <div className="border border-[#EAECF0] rounded-2xl p-6 bg-white hover:border-[#5B5FF6] hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-[#98A2B3]">
                  <FileText size={20} />
                </div>
                <button 
                  onClick={() => handleDownload('api-tests')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-[#5B5FF6] text-xs font-bold rounded-lg hover:bg-indigo-100 transition-colors"
                >
                  <Download size={14} /> Download
                </button>
              </div>
              <h3 className="text-sm font-bold text-[#101828] mb-2">API Test Cases Summary</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Comprehensive listing of all generated API test cases in PDF or ZIP format.
              </p>
            </div>
          </div>

          {/* Playwright Execution Report */}
          <div className="border border-[#EAECF0] rounded-2xl p-6 bg-white hover:border-[#5B5FF6] hover:shadow-md transition-all flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-[#98A2B3]">
                  <FileText size={20} />
                </div>
                <button 
                  onClick={() => handleDownload('report')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-[#5B5FF6] text-xs font-bold rounded-lg hover:bg-indigo-100 transition-colors"
                >
                  <Download size={14} /> Download
                </button>
              </div>
              <h3 className="text-sm font-bold text-[#101828] mb-2">Playwright Execution Report</h3>
              <p className="text-xs text-[#667085] leading-relaxed">
                Detailed HTML report containing traces, screenshots, and videos of UI test executions.
              </p>
            </div>
          </div>

          {/* Selenium Execution Report */}
          <div className="border border-[#EAECF0] rounded-2xl p-6 bg-white hover:border-[#5B5FF6] hover:shadow-md transition-all flex flex-col justify-between opacity-75">
            <div>
              <div className="flex justify-between items-start mb-6">
                <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-[#98A2B3]">
                  <FileText size={20} />
                </div>
                <button 
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 text-[#98A2B3] text-xs font-bold rounded-lg cursor-not-allowed"
                >
                  <Download size={14} /> Download
                </button>
              </div>
              <h3 className="text-sm font-bold text-[#101828] mb-2">Selenium Execution Report</h3>
              <p className="text-xs text-[#98A2B3] leading-relaxed">
                Coming Soon. Detailed HTML report containing logs and results of Selenium/API test executions.
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-start mt-8 pb-10 pl-2">
        <button 
          onClick={() => setActiveTab('results')}
          className="px-6 py-3 bg-white text-slate-700 font-bold rounded-xl shadow-sm border border-slate-200 hover:bg-slate-50 hover:shadow transition-all"
        >
          Back
        </button>
      </div>

    </div>
  );
}
